export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDc4bjcKcXJHal4Jz08-kdxHRdPNfuOVyA",
    authDomain: "school-app-3c901.firebaseapp.com",
    projectId: "school-app-3c901",
    storageBucket: "school-app-3c901.appspot.com",
    messagingSenderId: "947378574841",
    appId: "1:947378574841:web:7b2cd5a681a5b7de1e5928"
  },
};
